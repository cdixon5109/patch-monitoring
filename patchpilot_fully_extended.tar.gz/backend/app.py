
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_apscheduler import APScheduler
import psycopg2, os, paramiko, datetime

app = Flask(__name__, template_folder='../frontend/templates', static_folder='../frontend/static')
app.secret_key = 'secure_patchpilot_key'

DB_SETTINGS = {
    'host': 'localhost',
    'dbname': 'patchpilotdb',
    'user': 'patchpilotuser',
    'password': 'patchpilotpass'
}

class Config:
    SCHEDULER_API_ENABLED = True
app.config.from_object(Config())

scheduler = APScheduler()
scheduler.init_app(app)
scheduler.start()

def get_db():
    conn = psycopg2.connect(**DB_SETTINGS)
    return conn

def run_patch_check(ip, user, key_path, pkgmgr):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ip, username=user, key_filename=key_path)
        if pkgmgr == "yum":
            cmd = "yum check-update || true"
        elif pkgmgr == "apt":
            cmd = "apt list --upgradable 2>/dev/null || true"
        elif pkgmgr == "dnf":
            cmd = "dnf check-update || true"
        elif pkgmgr == "zypper":
            cmd = "zypper list-updates || true"
        else:
            return "Unknown package manager"

        stdin, stdout, stderr = ssh.exec_command(cmd)
        output = stdout.read().decode()
        return output.strip()
    except Exception as e:
        return f"Error: {str(e)}"
    finally:
        ssh.close()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT username, password, role FROM users WHERE username = %s', (username,))
        user = cur.fetchone()
        conn.close()
        if user and check_password_hash(user[1], password):
            session['user'] = user[0]
            session['role'] = user[2]
            return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT id, name, ip, ssh_user, pkg_mgr FROM servers')
    servers = cur.fetchall()
    conn.close()
    return render_template('dashboard.html', servers=servers, user=session['user'])

@app.route('/run_check/<int:server_id>')
def run_check(server_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT name, ip, ssh_user, ssh_key, pkg_mgr FROM servers WHERE id = %s', (server_id,))
    server = cur.fetchone()
    result = run_patch_check(server[1], server[2], server[3], server[4])
    cur.execute('INSERT INTO patch_logs (server_id, timestamp, result) VALUES (%s, %s, %s)',
                (server_id, datetime.datetime.now(), result))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/history/<int:server_id>')
def history(server_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT timestamp, result FROM patch_logs WHERE server_id = %s ORDER BY timestamp DESC', (server_id,))
    logs = cur.fetchall()
    conn.close()
    return render_template('history.html', logs=logs, server_id=server_id)

@app.route('/schedule_patch', methods=['GET', 'POST'])
def schedule_patch():
    if 'user' not in session or session['role'] != 'admin':
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()
    if request.method == 'POST':
        server_id = request.form['server_id']
        cron_expr = request.form['cron']
        job_id = f"patch_{server_id}"
        cur.execute('SELECT ip, ssh_user, ssh_key, pkg_mgr FROM servers WHERE id = %s', (server_id,))
        server = cur.fetchone()

        def scheduled_patch():
            result = run_patch_check(server[0], server[1], server[2], server[3])
            c2 = get_db().cursor()
            c2.execute('INSERT INTO patch_logs (server_id, timestamp, result) VALUES (%s, %s, %s)',
                       (server_id, datetime.datetime.now(), result))
            get_db().commit()

        # remove old job if it exists
        try:
            scheduler.remove_job(job_id)
        except:
            pass

        # add new cron-based job
        scheduler.add_job(id=job_id, func=scheduled_patch, trigger='cron', **parse_cron_expr(cron_expr))

        conn.close()
        return redirect('/dashboard')

    servers = cur.execute('SELECT id, name FROM servers').fetchall()
    conn.close()
    return render_template('schedule.html', servers=servers)

def parse_cron_expr(expr):
    parts = expr.split()
    return {
        'minute': parts[0],
        'hour': parts[1],
        'day': parts[2],
        'month': parts[3],
        'day_of_week': parts[4]
    }

@app.route('/deploy_patch/<int:server_id>')
def deploy_patch(server_id):
    if 'user' not in session:
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT ip, ssh_user, ssh_key, pkg_mgr FROM servers WHERE id = %s', (server_id,))
    server = cur.fetchone()
    ip, ssh_user, ssh_key, pkg_mgr = server

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ip, username=ssh_user, key_filename=ssh_key)
        if pkg_mgr == "yum":
            command = "yum update -y"
        elif pkg_mgr == "apt":
            command = "apt-get update && apt-get upgrade -y"
        elif pkg_mgr == "dnf":
            command = "dnf upgrade -y"
        elif pkg_mgr == "zypper":
            command = "zypper update -y"
        else:
            command = "echo 'Unknown package manager'"

        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode() + stderr.read().decode()
    except Exception as e:
        output = f"Patch deployment error: {str(e)}"
    finally:
        ssh.close()

    cur.execute('INSERT INTO patch_logs (server_id, timestamp, result) VALUES (%s, %s, %s)',
                (server_id, datetime.datetime.now(), output))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/users', methods=['GET', 'POST'])
def manage_users():
    if 'user' not in session or session['role'] != 'admin':
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()

    if request.method == 'POST':
        new_username = request.form['username']
        new_password = generate_password_hash(request.form['password'])
        new_role = request.form['role']
        cur.execute('INSERT INTO users (username, password, role) VALUES (%s, %s, %s)', (new_username, new_password, new_role))
        conn.commit()

    cur.execute('SELECT id, username, role FROM users')
    users = cur.fetchall()
    conn.close()
    return render_template('users.html', users=users)

@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    if 'user' not in session or session['role'] != 'admin':
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()
    cur.execute('DELETE FROM users WHERE id = %s', (user_id,))
    conn.commit()
    conn.close()
    return redirect('/users')

from werkzeug.utils import secure_filename

KEYS_DIR = '/opt/patchpilot/keys'
os.makedirs(KEYS_DIR, exist_ok=True)

@app.route('/upload_key', methods=['GET', 'POST'])
def upload_key():
    if 'user' not in session or session['role'] != 'admin':
        return redirect('/')
    if request.method == 'POST':
        file = request.files['keyfile']
        name = request.form['keyname']
        if file and name:
            filename = secure_filename(name)
            path = os.path.join(KEYS_DIR, filename)
            file.save(path)
    return render_template('upload_key.html')

@app.route('/analytics')
def analytics():
    if 'user' not in session:
        return redirect('/')
    conn = get_db()
    cur = conn.cursor()

    # Total servers
    cur.execute('SELECT COUNT(*) FROM servers')
    total = cur.fetchone()[0]

    # Servers patched in last 7 days
    cur.execute("""
        SELECT COUNT(DISTINCT server_id)
        FROM patch_logs
        WHERE timestamp >= NOW() - INTERVAL '7 days'
    """)
    patched = cur.fetchone()[0]

    # Total patch logs
    cur.execute('SELECT COUNT(*) FROM patch_logs')
    total_logs = cur.fetchone()[0]

    conn.close()
    return render_template('analytics.html',
                           total_servers=total,
                           patched_recently=patched,
                           patch_log_count=total_logs)

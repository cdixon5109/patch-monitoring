# PatchPilot Full Deployment

This package will include a fully functional Linux patch management app.
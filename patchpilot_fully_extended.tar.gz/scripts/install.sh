#!/bin/bash

echo "[+] Updating system and installing dependencies..."
sudo dnf update -y
sudo dnf install -y python3 python3-pip python3-venv nginx postgresql-server postgresql-contrib firewalld openssl

echo "[+] Initializing PostgreSQL..."
sudo postgresql-setup --initdb
sudo systemctl enable --now postgresql
sudo systemctl enable --now firewalld
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload

echo "[+] Creating PostgreSQL DB and user..."
sudo -u postgres psql -f /opt/patchpilot/database/init_patchpilot_pg.sql

echo "[+] Creating Python virtual environment..."
cd /opt/patchpilot
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install flask gunicorn flask-apscheduler psycopg2-binary paramiko

echo "[+] Generating self-signed SSL cert..."
sudo mkdir -p /etc/nginx/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/nginx/ssl/patchpilot.key \
  -out /etc/nginx/ssl/patchpilot.crt \
  -subj "/C=US/ST=State/L=City/O=PatchPilot/OU=Linux/CN=patchpilot.local"

echo "[+] Configuring NGINX..."
sudo tee /etc/nginx/conf.d/patchpilot.conf > /dev/null <<EOF
server {
    listen 443 ssl;
    server_name _;
    ssl_certificate /etc/nginx/ssl/patchpilot.crt;
    ssl_certificate_key /etc/nginx/ssl/patchpilot.key;
    location / {
        proxy_pass http://unix:/tmp/patchpilot.sock;
        include proxy_params;
    }
}
EOF

echo "[+] Creating Gunicorn systemd service..."
sudo tee /etc/systemd/system/patchpilot.service > /dev/null <<EOF
[Unit]
Description=PatchPilot Gunicorn Service
After=network.target

[Service]
User=root
Group=nginx
WorkingDirectory=/opt/patchpilot
ExecStart=/opt/patchpilot/venv/bin/gunicorn --workers 3 --bind unix:/tmp/patchpilot.sock backend.app:app

[Install]
WantedBy=multi-user.target
EOF

echo "[+] Starting services..."
sudo systemctl daemon-reload
sudo systemctl enable --now patchpilot nginx

echo "[+] PatchPilot deployed successfully at https://<your-server-ip>/"

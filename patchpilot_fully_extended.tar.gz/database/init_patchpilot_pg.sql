
CREATE USER patchpilotuser WITH PASSWORD 'patchpilotpass';
CREATE DATABASE patchpilotdb OWNER patchpilotuser;
\c patchpilotdb

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
);

CREATE TABLE servers (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    ip TEXT NOT NULL,
    ssh_user TEXT NOT NULL,
    ssh_key TEXT NOT NULL,
    pkg_mgr TEXT NOT NULL
);

CREATE TABLE patch_logs (
    id SERIAL PRIMARY KEY,
    server_id INTEGER REFERENCES servers(id) ON DELETE CASCADE,
    timestamp TIMESTAMP NOT NULL,
    result TEXT NOT NULL
);

-- Insert initial admin user (password is "admin")
INSERT INTO users (username, password, role) VALUES (
    'admin',
    '$pbkdf2-sha256$29000$FLJ5KxM1C5HzB5LVmX9hUw$Y6AyUvMHJoETuFlYyXqAmX1OQ.XRjTPNFWEFbvoZHeQ',
    'admin'
);
